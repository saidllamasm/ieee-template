<?php

/*echo  $_POST['user'];
echo  $_POST['pass'];
echo  $_POST['version'];
echo  $_POST['sucId'];
*/
require_once '../../../../wp-load.php';

try {
	init_Sincronizar($_POST['user'], $_POST['pass']);
}catch(Throwable $e) {
	echo $e;
}

function init_Sincronizar($user, $pass){
	$url = getURLSICARID($user,$pass);
	sincronizarArticulos($url, getJWT($url, $user, $pass), $user, $pass);
}

function sincronizarArticulos($url, $jwt, $username, $password){
	//create a new cURL resource
	$ch = curl_init($url.'/articulo/listaArtPorBajar');
	
	//setup request to send json via POST
	$data = array(
		'user' => $username,
		'pass' => $password,
		'version' => '190630',
		'sucId' => '2'
	);

	//attach encoded JSON string to the POST fields

	//set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization:'.$jwt));
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
	curl_setopt($ch, CURLOPT_VERBOSE, 1);

	//return response instead of outputting
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	//execute the POST request
	$result = curl_exec($ch);
	//close cURL resource
	//echo $result;
	curl_close($ch);
	$prods = json_decode($result, true);
	//print_r($prods);
	foreach ($prods as $prod) {
		if($prod['articulo']['tipo'] == 0 || $prod['articulo']['tipo'] == 2 || $prod['articulo']['tipo'] == 50 ){
			$objProduct = new WC_Product();
			$objProduct->set_name($prod['articulo']['descripcion']);
			$objProduct->set_status("publish");  // can be publish,draft or any wordpress post status
			$objProduct->set_catalog_visibility('visible'); // add the product visibility status
			$objProduct->set_description("Product Description ".generateRandomString(50));
			$objProduct->set_sku("sicar-sku".$prod['articulo']['claveAlterna']); //can be blank in case you don't have sku, but You can't add duplicate sku's
			$objProduct->set_price($prod['articulo']['precio1']); // set product price
			$objProduct->set_regular_price($prod['articulo']['precio1']); // set product regular price
			$objProduct->set_manage_stock(true); // true or false
			$objProduct->set_stock_quantity(10);
			$objProduct->set_stock_status('instock'); // in stock or out of stock value
			$objProduct->set_backorders('no');
			$objProduct->set_reviews_allowed(true);
			$objProduct->set_sold_individually(false);
			$objProduct->set_category_ids(array(1));
			$objProduct->save();
			echo $prod['articulo']['descripcion'] .'   ....... Agregado';
		}
	
	}
}

function getURLSICARID($username, $password){
	try {
		$xmlPetition = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.login.sicar/\">\n   <soapenv:Header/>\n   <soapenv:Body>\n      <ws:getUrlWsdl>\n         <!--Optional:-->\n         <user>".$username."</user>\n       \n         <pass>".$password."</pass>\n      </ws:getUrlWsdl>\n   </soapenv:Body>\n</soapenv:Envelope>";
		$responses = CURL('https://nubesicar.mx/LoginWS/LoginWS/getUrlWsdl', $xmlPetition);
		$final = substr($responses, 148);
		$urlarray = explode('</return>', $final);
		$nube = $urlarray[0];
		$dom = new DOMDocument;
		$dom->loadHTML($responses, LIBXML_COMPACT | LIBXML_HTML_NOIMPLIED | LIBXML_NONET);
		$b_nodelist = $dom->getElementsByTagName('return');
		foreach ($b_nodelist as $b) {
			$texto = $b->textContent;
		}
		if ($texto != null) {
			//sincronizarArticulos($texto, $username, $password);
			return $texto ;
		} else {
			// redirect login
			//return new WP_Error( 'authentication_failed', __( '' ) );
			return 0;
		}
	} catch (Throwable $th) {
		echo $th;
	}
}

function getJWT($url, $user, $pass){
	$data = array('user'=> $user, 'pass'=>$pass);
	
	$ch = curl_init( $url . '/login/signIn' );
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	
	$response = curl_exec($ch);
	
	if(!$response) {
		return 0;
	}else{
		$headers = array();
		$header_text = substr($response, 0, strpos($response, "\r\n\r\n"));
		foreach (explode("\r\n", $header_text) as $i => $line)
			if ($i == 0)
				$headers['http_code'] = $line;
			else {
				list ($key, $value) = explode(': ', $line);
				$headers[$key] = $value;
			}
		return $headers['Authorization'];
	}
	curl_close($ch);
}

function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}