<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://github.com/saidl14s
 * @since      1.0.0
 *
 * @package    Sicar_Id
 * @subpackage Sicar_Id/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Sicar_Id
 * @subpackage Sicar_Id/includes
 * @author     SICAR <said@sicar.mx>
 */
class Sicar_Id_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
