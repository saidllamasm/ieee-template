<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://github.com/saidl14s
 * @since             1.0.0
 * @package           Sicar_Id
 *
 * @wordpress-plugin
 * Plugin Name:       SICAR-ID
 * Plugin URI:        https://github.com/saidl14s
 * Description:       Iniciar sesión con tus credenciales de SICAR ID
 * Version:           1.0.0
 * Author:            SICAR
 * Author URI:        https://github.com/saidl14s
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       sicar-id
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'SICAR_ID_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-sicar-id-activator.php
 */
function activate_sicar_id() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-sicar-id-activator.php';
	Sicar_Id_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-sicar-id-deactivator.php
 */
function deactivate_sicar_id() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-sicar-id-deactivator.php';
	Sicar_Id_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_sicar_id' );
register_deactivation_hook( __FILE__, 'deactivate_sicar_id' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-sicar-id.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_sicar_id() {

	$plugin = new Sicar_Id();
	$plugin->run();

}
run_sicar_id();

/*
* Change the footer text
*/
function wptutsplus_admin_footer_text () {
	echo 'Powered by SICAR';
}

add_filter( 'admin_footer_text', 'wptutsplus_admin_footer_text' );

/*
*	Eliminar los enlaces a opciones no permitidas para los gestores de tienda
*/

function remove_menu_item() {
	$user = wp_get_current_user();
	//if ( $user->roles[0] != 'administrator' ) {
		remove_menu_page( 'edit-comments.php' );
		//remove_menu_page( 'index.php' );                  //Dashboard
		remove_menu_page( 'jetpack' );                    //Jetpack*
		remove_menu_page( 'edit.php' );                   //Posts
		//remove_menu_page( 'upload.php' );                 //Media
		remove_menu_page( 'edit.php?post_type=page' );    //Pages
		remove_menu_page( 'edit-comments.php' );          //Comments
		//remove_menu_page( 'themes.php' );                 //Appearance
		//remove_menu_page( 'plugins.php' );                //Plugins
		remove_menu_page( 'users.php' );                  //Users
		remove_menu_page( 'tools.php' );                  //Tools
		remove_menu_page( 'options-general.php' );        //Settings
		//mis paginas
		remove_menu_page('google-analyticator'); //Google analytics
		remove_menu_page('Wordfence'); //security
		remove_menu_page('feed-them-settings-page'); //redes sociales plugin
		remove_menu_page( 'edit.php?post_type=wpsl_stores' );    //Tiendas plugin
		remove_menu_page( 'wpcf7' );    //ContactForm
		remove_menu_page('ai1wm_export'); //importar extportar plugin
		remove_menu_page( 'admin.php?page=sicar-framework' );    //Ajustes de plantilla
		add_action('admin_head', 'custom_css_admin'); // desactivo botones con mas opciones para metabox en escritorio via css
	//}
}
add_action( 'admin_menu', 'remove_menu_item' );

function login_register_options_page() {
	  add_menu_page('SICAR', 'SICAR', 'manage_options', 'sicarid', 'login_page');
	  add_action( 'admin_init', 'register_plugin_settings' );
}
add_action('admin_menu', 'login_register_options_page');

function login_page() {
	global $woocommerce;
?>
	<form method="post" action="options.php">
		<?php settings_fields( 'sicarid-plugin-settings-group' ); ?>
		<?php do_settings_sections( 'sicarid-plugin-settings-group' ); ?>
		<table class="form-table">
			<tr valign="top">
			<th scope="row">Usuario</th>
			<td><input type="text" id="user_sicarid_plugin" name="user_sicarid_plugin" value="<?php echo esc_attr( get_option('user_sicarid_plugin') ); ?>" /></td>
			</tr>
			
			<tr valign="top">
			<th scope="row">Contraseña</th>
			<td><input type="text" id="pass_sicarid_plugin" name="pass_sicarid_plugin" value="<?php echo esc_attr( get_option('pass_sicarid_plugin') ); ?>" /></td>
			</tr>
		</table>
		<textarea id="Respuesta" style="height:200px; width:100%; background:white;"></textarea>
		
		<?php submit_button(); ?>
		<p class="submit"><input type="button" onclick="return solicitar();" name="sincronizar" id="sincronizar" class="button button-primary" value="SINCRONIZAR"></p>

	</form>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/javascript">
        function solicitar(){
            var user = document.getElementById('user_sicarid_plugin').value;
			var pass = document.getElementById('pass_sicarid_plugin').value;
           
			//create products
			$.ajax({
				//dataType: 'jsonp',
				async: false,
				crossDomain: true,
				//dataType: 'jsonp',
				type: 'POST',
                url: ' <?php echo plugins_url(); ?>' +'/sicar-id/functions/sincronizarArtBajar.php',
				data: {
					'user':user,
					'pass':pass,
					'version':'190630',
					'sucId':'2'
				},
                success:function(resp){
					/*for (var i=0, len=resp.length; i < len; i++) {
						$("#Respuesta").append(resp[i]+ '<br>');
					}*/
					$("#Respuesta").val(resp+ '<br>');
					console.log(resp);
                }
               ///wp-content/themes/CongresoSistemasComputacionales/php 
            });
            return false;
        }
    </script>
<?php
}


function register_plugin_settings() {
	//register our settings
	register_setting( 'sicarid-plugin-settings-group', 'user_sicarid_plugin' );
	register_setting( 'sicarid-plugin-settings-group', 'pass_sicarid_plugin' );
}

/*
* Rename Woocommerce
*/
add_action( 'admin_menu', 'rename_woocoomerce', 999 );
function rename_woocoomerce () {
	global $menu;
	// Pinpoint menu item
	$woo = rename_woocommerce( 'WooCommerce', $menu );
	// Validate
	if( !$woo )
		return;
	$menu[$woo][0] = 'Tienda';
}

function rename_woocommerce( $needle, $haystack ) {
	foreach( $haystack as $key => $value )
	{
		$current_key = $key;
		if(
			$needle === $value
			OR (
				is_array( $value )
				&& rename_woocommerce( $needle, $value ) !== false
			)
		)
		{
			return $current_key;
		}
	}
	return false;
}

/*
* Remove widget dashboard
*/
function remove_dashboard_meta() {
	remove_meta_box( 'dashboard_incoming_links', 'dashboard', 'normal' );
	remove_meta_box( 'dashboard_plugins', 'dashboard', 'normal' );
	remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
	remove_meta_box( 'dashboard_secondary', 'dashboard', 'normal' );
	remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
	remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );
	remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
	remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
	remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');//since 3.8
}

add_action( 'admin_init', 'remove_dashboard_meta' );

function wpb_login_logo() { ?>
	<style type="text/css">
		#login h1 a, .login h1 a {
			background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABI1BMVEX////4+Pjk5ecBXKsCTYbu7/D///0CS4AAS4P8/Pz2//8NSnoCTYUBXKne7PHh6u4BXK8ET4MIX5/x//8AXKb9/vn//f8ATYkAXLEAUZQAVJ4AWaH//fMAYLEAX7cAX6wAPnoAP3MAUJsATZ0ATZUATqMAVqOYtcwAPnQAOH3r5N4AQXFVc40FSogALFkAPXp1mr7/9/Hw//jV1dUALl4EP2zw+/9ylagALWxvkqyjtb9vlr1vnLTp/Pxpk8FxlLUAT7NRiL6FnbSKmaydt9QANHiDoLEAW7iCnLkANYEAMmt5l7zQ5OnL2OiywtLI2evM2N2+x8sMRm4ANl1ulJjo7vlqi6AAIU5RZYkAKmB5jaFNaIIAHEtVd4Vij6QAUX6Km6HN2RyPAAANk0lEQVR4nO1di3baxhY1FtZjELGIGATiKcBUDpENJIYQHNNrt0maJr2pe0tvkpu4//8V95yRHWsGDM6jlmDNXs1q3eVqaXMe++wzQt3akpCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJBIMoy4b+AfhrrhDCm1n9qqGvdt/HNQK2qv3SOVDaVoAOxxs9ac2sZmZiqhlEzcarbYmhK6kVE0Kva0VayWrRel42cVtRD3/XxnGJilk71iUclbNat0bNONY2gYg17TUhQF/ljZdm/japEM6EmrWs8qDNlqewK1aGxQNaoVewIE88olqgqKBt0QZVQpgEx/rCv5zwytIuuodDN6KjIkx6Ui8roiiH8BxcoGUFQhEQkdnOzV6goPrMVn608QGdIKmTQVpTzHUGlDFOO+wW+FqhoGtXstS8nmlTlYrZ5N11w0IILQZFpVoFMU+WWzQPGYqGtMETJUhQj+2ixW5+PHONZr7WO7sr4UkWGFnuzV6/nsYopW0Wr21rgWWQRHzZq1qAYZQStrgZl6tpaJivGDGjROWrW5AoxQzCtWzZ2S1BoOqUhwC+2SVb8hgFeoVtFMrSVDgxq9lhIZ1W6sxdIxoYV144hCiDpoQbGtYGhZtdaamSmWoXSgTpo1hc2gIYoo++Wwq2aVKO9irTmBGTXu+749kGGB2icQwSwXrGw228mX8/A3QT2KFpqp9YkiG9XIyC0WBZnIlztW2SlBJMXatKzOr0O6NpkKDFNk2qlZCh+rfLlcau7/a99yXZebAbJZ+HFvQtaCIWYoIZCie1aeixHwKJfL7uFTerrfLJVcJVqi+M/50oldoSRuAqvBRjXSaxUtvtayHeDXbDzd3SFA0e2UxVqsZtvHg8oaiEZol5oWP2xDHpZLbqn7w86Dnb7xslHquC7PMG9Z9ebETrgjVq/tkjhsQw26Je+H3e3tnUKKnB42S+Uy9yt5S8nX9qYk2fs3ZpdUewKjGtco4U+nXAKCf24Dw1QKKO63S+WO0ImUerU9sWmSdREnNdWY7lliDWbLLovgg0uGlJ7tO26nk8/yLdUqtkD6E9xSWQ1OnaIwp4U1+CokyBimKuT5k3an7AraHw5walIpYopWyGRP6KJZkAkg6P+EKXrFMEW3Xv7s3i+Vs+LUWnWndlLzFFqMOhBlAmfRLKvB3e0oQ6jF5w23BMONMBXU6+3xs4QeoVI6GB7vwajGh5B10e5likYY9gfQbkAkhV9XrGyzRxJ5MgUyMTgp1aoKrxMYwKsmwzGk/eHzRrPp8qJhFZV8tdNL2gDHRrUCJZNmNSoTFkbEBYLdzykaYcgS9bDNBjjeTOWr7Z6drG0428n0QeiVKm8awC2BTPhRglGGKft03wXREL3UixetXrL8ItqlChl1akWF07dwkvEjKSowNIyX+6UWOA2OYR7azR501ARlKjOEJ50XRYVnmHVBJ179xBHkGDLRgFp0uXYDelqstY5JKiEMcWWhUnviWsJdKgo0mbbHpajIEDg+/wXMVJnt+KNxrJemg4SYKXa6ZPSaVa4GrUuZmCMoMsR2484NcBDEItYinv/HTTDcbPda6Oj5agrtEp+iCxiCLqKZEhYb96EYm71E1CLzE+HpEt9Gy6GbEAnOMUz1wUy1RDNlAeruOPYl4+Vm+6TFDzJWGMIFKbqIIRMNKMXO3Aau1jyOWxcxQykdtWBUEyN4bZdWM+xDu5k3UzjfNKeDfqxhZDU4KQkqIdil1QzBTJ2CmcJa5NSmbhVdHOBio8hKkOARNtclsmEN+j8tSNHFDEkqtXX6cynNbH/0g4IBroXSH5doUAqTzLRV51MLbgxr0F9UgzfFEFmeHmItihOcArpoxzbAQQkOe674GMmcXbodwwJ5+UupIy4ZraKV3+sN4lpsoF3aq1fzFncGOmeXbseQiUbbFUQD+BZxyWjE4RcJ1OCkVYtuWtijh2Dcebt0S4Y43cAAV3atqJmCi9eLzcmAxnASDjV4LO5kcLU9Z5duzRCXjK15MwV0273hnS828HRpet/ijz/rS2ViNcP+AGtRFA2cb/YmBAa4OyUJDHs/FvN5zhBgkym1Rbt0e4ZYi0/aMMDNPZxSd3G6ucuHNXGz3QQzAUphhSgCLBhlWq9+2FnCbzlD1EUc4MpXsWNXVup5dkqcUu9OFwt08GtTqZbzPFgNLo/gKoYp9Qx00e2UuWvjT6WJXbi7jgqzaNOCnLx/jTLAcRwdavCbGFboqWc6pfsc8GTc2huTu8tSOtwF3OPx+vWbN7+9WRHBlQwpTb397c2/X98T8fr1biFGnwE9wEjtbD96tILeaoYAY/sR/pYhNJaY14vGbQnegmEqxSjGbX4FIMPb8LsdQ4P9WsIYplLLReKLGALF5DE0vivDhGbp96vDRwlkGKbp9+mlIcFUrL2T0u17u3N4/fb3338HPVxiLG7FEK7y9u3c1e/tbt/l3m04OsoAdF3XMtc4Pz//4+zPb4zh8OEfR93MPHLef+5wXUOpPfYdR8vlcpp+Da3bPTp4uYLiCobDh4993w90HhknfTgdVO7Q6dPKEChe5K6hAQIdKT5fTnEpQ4M8POh2M5puAiJXvzD9GS3c7UGNuvW+EVzkTCd9BQyipnW9v852l5XiMoaV4X/fHWXYhwVT/OV1Awd+9EZ3/z1+Qt77wE+PMoSq7GpHf50ui+Iyjz98+M7rIkHt+oNLm+kgOJyRGBhWyMxPO7l0FCyK3cenXxVDA2qw63l4DS1yTc1Bgv275sc2+mTsOWbkXpy0aUK78fyD51+zawOCR5kw1zUow6sQ6o4/prGsEwH2Jz+4vhe4G+w4ug/t5mz3wZftvIeQogdHGtLTIx8afGaBP4vvKNgYjBrpSC2a2FL1TKbbPTj9wp13HyPYZfGLMNTSQftwROP7Cl+B2rMj7AXXDDFPNb3rvTu9YRK/KYZYg5cZGu0yzuHI7scWQ7XAOmqg5S7vyjS1sKlmGv4BUrzdCSlJFdQPoIM6jg+RpIeJwmnMYqvBK9gjz+Q+9zRGAqT/f2cLK3FhDIcfDsIU1bkidKDJxL29gPFGRdEwoxRBNM4zXvevhQPcAoYF++MTIKgLGaqjDibgkWFKIVGjyg8fPdSi7p/77xZJ/zxDI/Xw1ZF3KRPRz8nxR6SfjKcUZ40gLMFopmY87+Bse9WzGFCDqY+P2SQTrUEHhCcNQp+QV6AQewRRTIu1eOR1F5ipuRjaTCYyOa4GdQdSdBT7wyZXIJRCu3G4IEItZjTURZGiyHD4EWZR6L680mtB8PN4kKBvCBvkfVcY4HTdYX7xbGcpQ/UDazIiQ9PxPw0KhUQ813YJMvNAFiNh1EPRADO1cyNDGNVAB8UOA3Ypd3E4Ttprz8jWey8I0lqUIZopvSuYqShDNotejmqRCII33B8l7lUEaoWMDgNHbKgAjxcNLobXo1r0PwtA6JP3yjNVJVtjP9Ajmu2w+S3TRdFYxJD5wa6og6bpBP4nYiSqBi+hPoPp5iLHBZHVYvfg7525Z/UJS1FvLkN1E2ZRO2EZegmDUNBFh5d+E0RD9yLrqZ3rGryyS1GVMFEHB0n9GqIKZgqkX9RFXE89/jyjXjI0CBBcaJcggol9pQvcFxk1nBynbGxpHBGNkGGffIBRTRdHNU0DP0jAlMVN5WYYZOQ5TmSAM1ktotP4ezfCcAgEwViKK4s0dtGkyYQAdTAD0ciZ0SDqYS2GorETygQYXk20SzkHa7AfvyNcBpWmIIrpCEPcGZthR2WWmDEEmWCLX56hGaBdSnCGXsGeHZoXOW6pi6Jxjk7jwfa9VIVNMqFMfCYYgJ1wDmdJ/6ozAveoIx8jInTUcw03cBBD3GzP7X0dsEuNkZ0MO7gCRqEyWLgN1z3/8emfO+x0aW5U0xzHnw0S+b3DeYAxR110ohFCM6V7HtTi8OMfkKEZKMNclGEO7JKdNDtxM1TDHh9Ce0lHWIYnjLp/EZZgdFQLzJwOdmkNWkwEBZD+wDGFITVo6Hr3PJMRzUQaZYKsTQAZChXy3k+bGa4WoZlo6DZEhloQoF1aL4YU3A+0Gy3SUcHXOjmQfj0Uws//3jQ1PD4zYvtWxVcjZY99UzMdTheBXy6X4zbb8CE0xoO47/YrADk3QNfPmSnTxBP66CCjpQMH7VLct/vlMNirdWdeWmDIDwKgEunAn63ruxMJHts0nOipvEhQMzWnMSJqku3ScqCZChwxbtH2CkJ/hw83/wNQWS3mtIX0TD1wGmOaoM32V4BSGMNvYqiZKPRrWoPXMNBM4WmumJ+4smjMNuKV3hjFtCkyNLEGR+vgB5fDMNBMgfQLZgpkAkY1sEvrnqIIfKP3J38Bw8Y47m9qfz8YhNViOrhqMTkt0Buj+I/ovyPs0WGkEDV2wrtmdmk50Ex5OKJ9rkFv7ezScqgFMFOvnBxMN+zAv9T4pG5Ujm5hUyVj8Is5XKqlYZLZqBRFGIZagAEOTLAJdskfbYRKiFDxkdsgyJmOtwGj2iKoBRzggozZGK+zXVoBApbY37wavEahT0ZPxupGpuglVJU83dD/JdkVCkbCzz+/HZvOT0JCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQmLd8X+mI7Pu7xeFuQAAAABJRU5ErkJggg==);
		height:100px;
		width:300px;
		background-size: 300px 100px;
		background-repeat: no-repeat;
		padding-bottom: 10px;
		}
	</style>
<?php }
add_action( 'login_enqueue_scripts', 'wpb_login_logo' );


function wpb_login_logo_url() {
    return 'https://www.sicar.mx/';
}
add_filter( 'login_headerurl', 'wpb_login_logo_url' ); 

function wpb_login_logo_url_title() {
    return '';
}
add_filter( 'login_headertitle', 'wpb_login_logo_url_title' );

function custom_login_error_message() {
	return 'Ingresar los datos de tu SICAR-ID o';
}
//add_filter('login_errors', 'custom_login_error_message');

function custom_login_redirect( $redirect_to, $request, $user ) {
	/*global $user;
	if( isset( $user->roles ) && is_array( $user->roles ) ) {
		return $redirect_to;
		//return home_url();
	} else {
		return $redirect_to;
	}*/
	return $redirect_to;
}
//add_filter("login_redirect", "custom_login_redirect", 10, 3);

/* Where to go if any of the fields were empty */
function authenticate($user, $username, $password){
	if ( $user == null ) {
		//$password
		//return $password;
		loginWithSICARID($username, $password);
		//return new WP_Error( 'authentication_failed', __( '<strong>ERRsOR</strong>: Invalid username '.$username.', email address or incorrect password.' ) );
	}
	
}
add_filter('authenticate', 'authenticate', 10, 3);


/*  */
function loginWithSICARID($username, $password){
	try {
		$xmlPetition = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.login.sicar/\">\n   <soapenv:Header/>\n   <soapenv:Body>\n      <ws:getUrlWsdl>\n         <!--Optional:-->\n         <user>".$username."</user>\n       \n         <pass>".$password."</pass>\n      </ws:getUrlWsdl>\n   </soapenv:Body>\n</soapenv:Envelope>";
		$responses = CURL('https://nubesicar.mx/LoginWS/LoginWS/getUrlWsdl', $xmlPetition);
		$final = substr($responses, 148);
		$urlarray = explode('</return>', $final);
		$nube = $urlarray[0];
		$dom = new DOMDocument;
		$dom->loadHTML($responses, LIBXML_COMPACT | LIBXML_HTML_NOIMPLIED | LIBXML_NONET);
		$b_nodelist = $dom->getElementsByTagName('return');
		foreach ($b_nodelist as $b) {
			$texto = $b->textContent;
		}
		if ($texto != null) {
			echo $texto;
			exit;
		} else {
			// redirect login
			return new WP_Error( 'authentication_failed', __( '' ) );
		}
	} catch (\Throwable $th) {
		echo $th;
	}
}

function CURL($url, $field) {
    try {
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url ,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => $field,
		));
		$responseD = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		if ($status == 200) {
			return $responseD;
		}
    } catch (Exception $e) {
        print_r($e);
    }
}