<?php

	//framework de opciones
	require_once dirname( __FILE__ ) .'/cs-framework/cs-framework.php';

	// Registro del menú de WordPress
	register_nav_menus(
		array(
			'Opciones'		=>		'Menú Opciones', 
			'Principal'		=>		'Menú Principal',
			'Footer'		=>		'Menú Footer',
	));

	// Right sidebar
	function sidebar_widgets() {
		register_sidebar( array(
			'name'          => 'Right sidebar',
			'id'            => 'home_right',
			'before_widget' => '<div>',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="rounded">',
			'after_title'   => '</h2>',
		) );
	}

	add_action( 'widgets_init', 'sidebar_widgets' );


    //añadiendo soporte a imagenes miniaturas en posts
    add_theme_support('post-thumbnails');
	set_post_thumbnail_size(225, 150, true);

	//modificar el extracto
	function extracto_leermas() {
		global $post;
		return '<a href="'. get_permalink($post->ID) . '" > Leer más</a>';
	}
	add_filter('excerpt_more', 'extracto_leermas');

	//modificar contact form 7
	
	add_filter('wpcf7_form_elements', function($content) {
	    $content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);

	    return $content;
	});

	//importar recursos
	function resources() {
		wp_enqueue_script( 'jQuery', get_template_directory_uri().'/assets/js/core/jquery.3.2.1.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'Popper', get_template_directory_uri().'/assets/js/core/popper.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'Bootstrap', get_template_directory_uri().'/assets/js/core/bootstrap.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'BootstrapSwitch', get_template_directory_uri().'/assets/js/plugins/bootstrap-switch.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'Nouislider', get_template_directory_uri().'/assets/js/plugins/nouislider.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'Datepicker', get_template_directory_uri().'/assets/js/plugins/bootstrap-datepicker.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'Main', get_template_directory_uri().'/assets/js/now-ui-kit.js', array( 'jquery' ), '1.1.0', true );

		wp_enqueue_style("BootstrapStyle", get_template_directory_uri().'/assets/css/bootstrap.min.css');
		wp_enqueue_style("style", get_stylesheet_uri());
		wp_enqueue_style("FontAwesome", 'https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css');
	}

	add_action( 'wp_enqueue_scripts', 'resources' );
	/**
	 * Custom admin login header logo
	 */
	function custom_login_logo() {
		echo '<style type="text/css">'.
					'h1 a { background-image:url(http://www.sicar.mx/wp-content/uploads/2014/10/logotipo.png) !important; }'.
				'</style>';
	}
	add_action( 'login_head', 'custom_login_logo' );

	/**
	 * Custom admin login header link alt text
	 */
	function custom_login_title() {
		return get_option( 'blogname' );
	}
	add_filter( 'login_headertitle', 'custom_login_title' );
	/*
	* Change the footer text
	*/
	function admin_footer_message () {
		echo 'SICAR eCommerce';
	}
	add_filter( 'admin_footer_text', 'admin_footer_message' );
	/*
	*	Eliminar los enlaces a opciones no permitidas para los gestores de tienda
	*/
	function remove_items_admin_page() {
		$user = wp_get_current_user();
			//if ( $user->roles[0] != 'administrator' ) {
			remove_menu_page( 'edit-comments.php' );
			//remove_menu_page( 'index.php' );                  //Dashboard
			remove_menu_page( 'jetpack' );                    //Jetpack*
			remove_menu_page( 'edit.php' );                   //Posts
			remove_menu_page( 'upload.php' );                 //Media
			remove_menu_page( 'edit.php?post_type=page' );    //Pages
			remove_menu_page( 'edit-comments.php' );          //Comments
			remove_menu_page( 'themes.php' );                 //Appearance
			remove_menu_page( 'plugins.php' );                //Plugins
			remove_menu_page( 'users.php' );                  //Users
			remove_menu_page( 'tools.php' );                  //Tools
			remove_menu_page( 'options-general.php' );        //Settings
			//mis paginas
			remove_menu_page('google-analyticator'); //Google analytics
			remove_menu_page('Wordfence'); //security
			remove_menu_page('feed-them-settings-page'); //redes sociales plugin
			remove_menu_page( 'edit.php?post_type=wpsl_stores' );    //Tiendas plugin
			remove_menu_page( 'wpcf7' );    //ContactForm
			remove_menu_page('ai1wm_export'); //importar extportar plugin
			remove_menu_page( 'admin.php?page=ieee-theme-options' );    //Ajustes de plantilla
			add_action('admin_head', 'custom_css_admin'); // desactivo botones con mas opciones para metabox en escritorio via css
		//}
	}
	add_action( 'admin_menu', 'remove_items_admin_page' );
?>