## Template for WordPress of IEEE Branch ITCG by Said Llamas
###### saidllamas@ieee.org 
> advancing technology for the benefit of humanity. 

### Acerca de
Esta plantilla fue realizada para el website de la Rama Estudiantil IEEE del ITCG.
