
<!doctype html>
<html lang="es">

  <head>
    
      

  <meta charset="utf-8">


  <meta http-equiv="x-ua-compatible" content="ie=edge">



  <title>ecommerce sicar</title>
  <meta name="description" content="Tienda creada con ecommerce sicar">
  <meta name="keywords" content="">
      
                  <link rel="alternate" href="http://finaltest2.com/index.php?id_lang=1" hreflang="es">
        



  <meta name="viewport" content="width=device-width, initial-scale=1.0">



  <link rel="icon" type="image/vnd.microsoft.icon" href="/img/favicon.ico?1324977642">
  <link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico?1324977642">



    <link rel="stylesheet" href="http://finaltest2.com/themes/classic/assets/css/theme.css" type="text/css" media="all">
  <link rel="stylesheet" href="http://finaltest2.com/js/jquery/ui/themes/base/minified/jquery-ui.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="http://finaltest2.com/js/jquery/ui/themes/base/minified/jquery.ui.theme.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="http://finaltest2.com/modules/ps_imageslider/css/homeslider.css" type="text/css" media="all">
  <link rel="stylesheet" href="http://finaltest2.com/themes/classic/assets/css/custom.css" type="text/css" media="all">




  

  <script type="text/javascript">
        var prestashop = {"cart":{"products":[],"totals":{"total":{"type":"total","label":"Total","amount":0,"value":"0,00\u00a0$"},"total_including_tax":{"type":"total","label":"Total (impuestos incl.)","amount":0,"value":"0,00\u00a0$"},"total_excluding_tax":{"type":"total","label":"Total (impuestos excl.)","amount":0,"value":"0,00\u00a0$"}},"subtotals":{"products":{"type":"products","label":"Subtotal","amount":0,"value":"0,00\u00a0$"},"discounts":null,"shipping":{"type":"shipping","label":"Transporte","amount":0,"value":"Gratis"},"tax":null},"products_count":0,"summary_string":"0 art\u00edculos","vouchers":{"allowed":0,"added":[]},"discounts":[],"minimalPurchase":0,"minimalPurchaseRequired":""},"currency":{"name":"Peso mexicano","iso_code":"MXN","iso_code_num":"978","sign":"$"},"customer":{"lastname":null,"firstname":null,"email":null,"birthday":null,"newsletter":null,"newsletter_date_add":null,"optin":null,"website":null,"company":null,"siret":null,"ape":null,"is_logged":false,"gender":{"type":null,"name":null},"addresses":[]},"language":{"name":"Espa\u00f1ol (Spanish)","iso_code":"es","locale":"es-ES","language_code":"es","is_rtl":"0","date_format_lite":"d\/m\/Y","date_format_full":"d\/m\/Y H:i:s","id":1},"page":{"title":"","canonical":null,"meta":{"title":"ecommerce sicar","description":"Tienda creada con ecommerce sicar","keywords":"","robots":"index"},"page_name":"index","body_classes":{"lang-es":true,"lang-rtl":false,"country-MX":true,"currency-MXN":true,"layout-full-width":true,"page-index":true,"tax-display-enabled":true},"admin_notifications":[]},"shop":{"name":"ecommerce sicar","logo":"\/img\/logo.png","stores_icon":"\/img\/logo_stores.png","favicon":"\/img\/favicon.ico"},"urls":{"base_url":"http:\/\/finaltest2.com\/","current_url":"http:\/\/finaltest2.com\/index.php","shop_domain_url":"http:\/\/finaltest2.com","img_ps_url":"http:\/\/finaltest2.com\/img\/","img_cat_url":"http:\/\/finaltest2.com\/img\/c\/","img_lang_url":"http:\/\/finaltest2.com\/img\/l\/","img_prod_url":"http:\/\/finaltest2.com\/img\/p\/","img_manu_url":"http:\/\/finaltest2.com\/img\/m\/","img_sup_url":"http:\/\/finaltest2.com\/img\/su\/","img_ship_url":"http:\/\/finaltest2.com\/img\/s\/","img_store_url":"http:\/\/finaltest2.com\/img\/st\/","img_col_url":"http:\/\/finaltest2.com\/img\/co\/","img_url":"http:\/\/finaltest2.com\/themes\/classic\/assets\/img\/","css_url":"http:\/\/finaltest2.com\/themes\/classic\/assets\/css\/","js_url":"http:\/\/finaltest2.com\/themes\/classic\/assets\/js\/","pic_url":"http:\/\/finaltest2.com\/upload\/","pages":{"address":"http:\/\/finaltest2.com\/index.php?controller=address","addresses":"http:\/\/finaltest2.com\/index.php?controller=addresses","authentication":"http:\/\/finaltest2.com\/index.php?controller=authentication","cart":"http:\/\/finaltest2.com\/index.php?controller=cart","category":"http:\/\/finaltest2.com\/index.php?controller=category","cms":"http:\/\/finaltest2.com\/index.php?controller=cms","contact":"http:\/\/finaltest2.com\/index.php?controller=contact","discount":"http:\/\/finaltest2.com\/index.php?controller=discount","guest_tracking":"http:\/\/finaltest2.com\/index.php?controller=guest-tracking","history":"http:\/\/finaltest2.com\/index.php?controller=history","identity":"http:\/\/finaltest2.com\/index.php?controller=identity","index":"http:\/\/finaltest2.com\/index.php","my_account":"http:\/\/finaltest2.com\/index.php?controller=my-account","order_confirmation":"http:\/\/finaltest2.com\/index.php?controller=order-confirmation","order_detail":"http:\/\/finaltest2.com\/index.php?controller=order-detail","order_follow":"http:\/\/finaltest2.com\/index.php?controller=order-follow","order":"http:\/\/finaltest2.com\/index.php?controller=order","order_return":"http:\/\/finaltest2.com\/index.php?controller=order-return","order_slip":"http:\/\/finaltest2.com\/index.php?controller=order-slip","pagenotfound":"http:\/\/finaltest2.com\/index.php?controller=pagenotfound","password":"http:\/\/finaltest2.com\/index.php?controller=password","pdf_invoice":"http:\/\/finaltest2.com\/index.php?controller=pdf-invoice","pdf_order_return":"http:\/\/finaltest2.com\/index.php?controller=pdf-order-return","pdf_order_slip":"http:\/\/finaltest2.com\/index.php?controller=pdf-order-slip","prices_drop":"http:\/\/finaltest2.com\/index.php?controller=prices-drop","product":"http:\/\/finaltest2.com\/index.php?controller=product","search":"http:\/\/finaltest2.com\/index.php?controller=search","sitemap":"http:\/\/finaltest2.com\/index.php?controller=sitemap","stores":"http:\/\/finaltest2.com\/index.php?controller=stores","supplier":"http:\/\/finaltest2.com\/index.php?controller=supplier","register":"http:\/\/finaltest2.com\/index.php?controller=authentication&create_account=1","order_login":"http:\/\/finaltest2.com\/index.php?controller=order&login=1"},"alternative_langs":{"es":"http:\/\/finaltest2.com\/index.php?id_lang=1"},"theme_assets":"\/themes\/classic\/assets\/","actions":{"logout":"http:\/\/finaltest2.com\/index.php?mylogout="},"no_picture_image":{"bySize":{"small_default":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-small_default.jpg","width":98,"height":98},"cart_default":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-cart_default.jpg","width":125,"height":125},"home_default":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-home_default.jpg","width":250,"height":250},"medium_default":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-medium_default.jpg","width":452,"height":452},"large_default":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-large_default.jpg","width":800,"height":800}},"small":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-small_default.jpg","width":98,"height":98},"medium":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-home_default.jpg","width":250,"height":250},"large":{"url":"http:\/\/finaltest2.com\/img\/p\/es-default-large_default.jpg","width":800,"height":800},"legend":""}},"configuration":{"display_taxes_label":true,"display_prices_tax_incl":false,"is_catalog":false,"show_prices":true,"opt_in":{"partner":true},"quantity_discount":{"type":"discount","label":"Descuento"},"voucher_enabled":0,"return_enabled":0},"field_required":[],"breadcrumb":{"links":[{"title":"Inicio","url":"http:\/\/finaltest2.com\/index.php"}],"count":1},"link":{"protocol_link":"http:\/\/","protocol_content":"http:\/\/"},"time":1571757985,"static_token":"051c70ceb8e5a2447771b4c90655d095","token":"19be8a9f85c96f8b9c46b3d2abd1d052"};
      </script>



  



    
  </head>

  <body id="index" class="lang-es country-mx currency-mxn layout-full-width page-index tax-display-enabled">

    
      
    

    <main>
      
              

      <header id="header">
        
          
    <div class="header-banner">
        
    </div>



    <nav class="header-nav">
        <div class="container">
            <div class="row">
                <div class="hidden-sm-down">
                    <div class="col-md-5 col-xs-12">
                        <div id="_desktop_contact_link">
  <div id="contact-link">
          <a href="http://finaltest2.com/index.php?controller=contact">Contacte con nosotros</a>
      </div>
</div>

                    </div>
                    <div class="col-md-7 right-nav">
                        <div id="_desktop_user_info">
  <div class="user-info">
          <a
        href="http://finaltest2.com/index.php?controller=my-account"
        title="Acceda a su cuenta de cliente"
        rel="nofollow"
      >
        <i class="material-icons"></i>
        <span class="hidden-sm-down">Iniciar sesión</span>
      </a>
      </div>
</div>
<style>
    .bagshopping {
        height: 60px;
        width: 60px;
        border-radius: 50%;
        background: #81C9EB;
        padding-top: 14.5px;
        padding-left: 14.5px;
    }
    .tesx{
        margin-top: -50px;
        margin-left: 60px;
    }
    .header{
        margin-top: -10px;
    }
    @media only screen and (max-width: 767px) {
        .tesx{
            margin-top: -70px;
            margin-left: 60px;
        }
    }
    @media only screen and (max-width: 750px) {
        .bagshopping {
            height: 0;
            width: 0;
            border-radius: 0;
            background: none;
            padding-top: 0;
            padding-left: 0;
        }
        .tesx{
            margin-top: -20px;
            margin-left: 25px;
            font-size: 9px;
        }
    }
    @media only screen and (max-width: 1199px) {
        .header{
            margin-top: -175px;
        }
    }

    @media only screen and (max-width: 991px) {
        .header{
            margin-top: -195px;
        }
    }


</style>
<div class="posi">
<div id="_desktop_cart">
    <div class="blockcart cart-preview inactive"
         data-refresh-url="//finaltest2.com/index.php?fc=module&amp;module=ps_shoppingcart&amp;controller=ajax">
        <div class="header">

                                            <div class="bagshopping">

                    <i class=""><img
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAprAAAKawGnuIHJAAABmElEQVRYhc1WwXHCMBBcuYGYDpwKoATTASWkBEqgBEogHbgE04GpIOogooLNQ7I43xAjCBLZmRt7pJV2R6O7kyEJgRrAFkCLPOgB7AG4OEJSxoH5cZCaUrwtID6i1QZqklaRtpyezl9iq/a2QTMa2CtC/0TxMXqlsR8NrNSEI9lkMNCEvSVWINmpwV0G8TF2SqszJB2AN5EqJlMKxsQT/2dDTgtBaVQAji/UP1aQVak8XAVgeKGBoQJgE4gn+Mu5TuCuA/eUwLWpBpYJnEfWWEOyBvCdQH6HNzuXNWf4jtoA+ErYc3HPJWzD93OG0ynuLbjf6vQ1dDMllZyWcF1dr6GnaEYpC0jfN8b+IbunVXMp6EiiCkeRmooHwW/gb/w6/A+KcwsDgGjAJi5aKoE+hDSYmjFek4+9hgaSG1663CaM3YOWJAx9L0pNxWdiAcCNBoD5/M4BA1zuAJBWOp+FqCUNlOyKUUsa6AsaiFr/6gRKvguiljRgCxqIWjINgXKpGF/elZoo8UCdaOgTqOHreZ1J3AH4gLiEP4ZZS51KPW5WAAAAAElFTkSuQmCC"
                                alt=""></i>
                </div>
                <div class="tesx">
                    <span class="hidden-sm-down">Carrito</span>
                    <br>
                    <span class="cart-products-count">0 Articulos</span>
                </div>
                        </div>
    </div>
</div>
</div>
                    </div>
                </div>
                <div class="hidden-md-up text-sm-center mobile">
                    <div class="float-xs-left" id="menu-icon">
                        <i class="material-icons d-inline">&#xE5D2;</i>
                    </div>
                    <div class="float-xs-right" id="_mobile_cart"></div>
                    <div class="float-xs-right" id="_mobile_user_info"></div>
                    <div class="top-logo" id="_mobile_logo"></div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </nav>

<style>
    .headTool{
        padding-top: 35px;
    }
</style>

    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-md-2 hidden-sm-down" id="_desktop_logo">
                                            <h1>
                            <a href="http://finaltest2.com/">
                                <img class="logo img-responsive" src="/img/logo.png" alt="ecommerce sicar">
                            </a>
                        </h1>
                                    </div>
                <div class="col-md-10 col-sm-12 position-static">
                    <div class="row">

                    <div class="headTool">

                        <style>
    .jsjd {
        margin: 10px 0 0 10px;
        padding-top: 5%;
        margin-left: -3.5%;
    }

    @media only screen and (max-width: 1000px) {
        .jsjd {
            margin: 10px 0 0 10px;
            padding-top: 15%;
        }

    }
</style>

<div class="jsjd">
        
    <div class="menu js-top-menu position-static hidden-sm-down" id="_desktop_top_menu">
        
                    <ul class="top-menu" id="top-menu" data-depth="0">
                                                                        <li class="category" id="category-3">
                                                <a
                                class="dropdown-item"
                                href="http://finaltest2.com/index.php?id_category=3&amp;controller=category" data-depth="0"
                                                        >
                                                                                                                            <span class="float-xs-right hidden-md-up">
                    <span data-target="#top_sub_menu_83188" data-toggle="collapse"
                          class="navbar-toggler collapse-icons">
                      <i class="material-icons add">&#xE313;</i>
                      <i class="material-icons remove">&#xE316;</i>
                    </span>
                  </span>
                                                        Clothes
                        </a>
                                                    <div  class="popover sub-menu js-sub-menu collapse"                                    id="top_sub_menu_83188">
                                
                    <ul class="top-menu"  data-depth="1">
                                                                        <li class="category" id="category-4">
                                                <a
                                class="dropdown-item dropdown-submenu"
                                href="http://finaltest2.com/index.php?id_category=4&amp;controller=category" data-depth="1"
                                                        >
                                                        Men
                        </a>
                                            </li>

                                                        <li class="category" id="category-5">
                                                <a
                                class="dropdown-item dropdown-submenu"
                                href="http://finaltest2.com/index.php?id_category=5&amp;controller=category" data-depth="1"
                                                        >
                                                        Women
                        </a>
                                            </li>

                            </ul>
            
                            </div>
                                            </li>

                                                        <li class="category" id="category-6">
                                                <a
                                class="dropdown-item"
                                href="http://finaltest2.com/index.php?id_category=6&amp;controller=category" data-depth="0"
                                                        >
                                                                                                                            <span class="float-xs-right hidden-md-up">
                    <span data-target="#top_sub_menu_21367" data-toggle="collapse"
                          class="navbar-toggler collapse-icons">
                      <i class="material-icons add">&#xE313;</i>
                      <i class="material-icons remove">&#xE316;</i>
                    </span>
                  </span>
                                                        Accesorios
                        </a>
                                                    <div  class="popover sub-menu js-sub-menu collapse"                                    id="top_sub_menu_21367">
                                
                    <ul class="top-menu"  data-depth="1">
                                                                        <li class="category" id="category-7">
                                                <a
                                class="dropdown-item dropdown-submenu"
                                href="http://finaltest2.com/index.php?id_category=7&amp;controller=category" data-depth="1"
                                                        >
                                                        Stationery
                        </a>
                                            </li>

                                                        <li class="category" id="category-8">
                                                <a
                                class="dropdown-item dropdown-submenu"
                                href="http://finaltest2.com/index.php?id_category=8&amp;controller=category" data-depth="1"
                                                        >
                                                        Home Accessories
                        </a>
                                            </li>

                            </ul>
            
                            </div>
                                            </li>

                                                        <li class="category" id="category-9">
                                                <a
                                class="dropdown-item"
                                href="http://finaltest2.com/index.php?id_category=9&amp;controller=category" data-depth="0"
                                                        >
                                                        Art
                        </a>
                                            </li>

                            </ul>
            
        <div class="clearfix"></div>
    </div>
</div><style>
    .jsjds {
        margin-top: -11.5%;
        padding-left: 15%;
        position: absolute;
        /*   padding-top: 10px;*/

    }

    .fffs {
        background: #F1F1F1;
    }

    @media only screen and (max-width: 767px) {
        .jsjds {
            margin-top: -10%;
            padding-top: 8%;
            padding-left: 5%;
            position: absolute;
        }
    }

    @media only screen and (max-width: 400px) {
        .jsjds {
            margin-top: -10%;
            padding-top: 4%;
            padding-left: 5%;
            position: absolute;
        }
    }
    @media only screen and (max-width: 250px) {
        .jsjds {
            margin-top: -10%;
            padding-top: 0%;
            padding-left: 5%;
            position: absolute;
        }
    }

    @media only screen and (max-width: 210px) {
        .jsjds {
            margin-top: -10%;
            padding-top: -10%;
            padding-left: 5%;
            position: absolute;
        }
    }

    @media only screen and (max-width: 1000px) {
        .jsjds {
            margin-top: -20%;
            padding-left: 5%;
            position: absolute;
        }
    }

    @media only screen and (max-width: 1199px) {
        .jsjds {
            margin-top: -17%;
            padding-left: 5%;
            position: absolute;
        }
    }

    @media only screen and (max-width: 991px) {
        .jsjds {
            margin-top: -26%;
            padding-left: 5%;
            position: absolute;
        }
    }

</style>

<div class="jsjds">
    <div id="search_widget" class="search-widget" data-search-controller-url="//finaltest2.com/index.php?controller=search">
        <form method="get" action="//finaltest2.com/index.php?controller=search">
            <input type="hidden" name="controller" value="search">
            <input type="text" class="fffs" name="s" size="50" value=""
                   placeholder="Búsqueda en catálogo"
                   aria-label="Buscar">
            <button type="submit">
                <i class="material-icons search">&#xE8B6;</i>
                <span class="hidden-xl-down">Buscar</span>
            </button>
        </form>
    </div>


</div>


<!-- /Block search module TOP -->


                    </div>

                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div id="mobile_top_menu_wrapper" class="row hidden-md-up" style="display:none;">
                <div class="js-top-menu mobile" id="_mobile_top_menu"></div>
                <div class="js-top-menu-bottom">
                    <div id="_mobile_currency_selector"></div>
                    <div id="_mobile_language_selector"></div>
                    <div id="_mobile_contact_link"></div>
                </div>
            </div>
        </div>
    </div>
    

        
      </header>

      
        

<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
      <section id="wrapper">
        
        <div class="container">
          
            <nav data-depth="1" class="breadcrumb hidden-sm-down">
    <ol class="lis" itemscope itemtype="http://schema.org/BreadcrumbList">
        
                            
                                            <li class="poss" id="juin" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                            <a itemprop="item" href="http://finaltest2.com/index.php">
                                <span itemprop="name">Inicio</span>
                            </a>
                            <meta itemprop="position" content="1">
                        </li>
                                                                <li class="po"  id="juin" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                        <a itemprop="item" href="http://finaltest2.com/index.php">
                            <span itemprop="name">Inicio</span>
                        </a>
                        <meta itemprop="position" content="1">
                    </li>
                
                    
    </ol>
</nav>
          

          

          
  <div id="content-wrapper">
    
    

  <section id="main">

    
      
    

    
    <section id="content" class="page-home">

        

        
            

                <div class="rtes">
                            
<div class="headdd" style="background: ">
     <div><i class="material-icons">dehaze</i></div>

    <div class="toppppp">CATEGORIAS</div>
</div>
<div class="block-categories hidden-sm-down">
    <ul class="category-top-menu">


        <li><a class="text-uppercase h6" href="http://finaltest2.com/index.php?id_category=2&controller=category">Inicio</a></li>
        <li>
    <ul class="category-sub-menu" ><li data-depth="0"><a href="http://finaltest2.com/index.php?id_category=3&amp;controller=category">Clothes</a><div class="navbar-toggler collapse-icons" data-toggle="collapse" data-target="#exCollapsingNavbar3"><i class="material-icons add">&#xE145;</i><i class="material-icons remove">&#xE15B;</i></div><div class="collapse" id="exCollapsingNavbar3">
    <ul class="category-sub-menu" ><li data-depth="1"><a class="category-sub-link" href="http://finaltest2.com/index.php?id_category=4&amp;controller=category">Men</a></li><li data-depth="1"><a class="category-sub-link" href="http://finaltest2.com/index.php?id_category=5&amp;controller=category">Women</a></li></ul></div><div class="yyyy"></div></li><li data-depth="0"><a href="http://finaltest2.com/index.php?id_category=6&amp;controller=category">Accesorios</a><div class="navbar-toggler collapse-icons" data-toggle="collapse" data-target="#exCollapsingNavbar6"><i class="material-icons add">&#xE145;</i><i class="material-icons remove">&#xE15B;</i></div><div class="collapse" id="exCollapsingNavbar6">
    <ul class="category-sub-menu" ><li data-depth="1"><a class="category-sub-link" href="http://finaltest2.com/index.php?id_category=7&amp;controller=category">Stationery</a></li><li data-depth="1"><a class="category-sub-link" href="http://finaltest2.com/index.php?id_category=8&amp;controller=category">Home Accessories</a></li></ul></div><div class="yyyy"></div></li><li data-depth="0"><a href="http://finaltest2.com/index.php?id_category=9&amp;controller=category">Art</a><div class="yyyy"></div></li></ul></li>
    </ul>
</div>

                </div>

                <style>
  .slider {
    background: #BEC3C4;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    opacity: 0.6;
  }

  @media only screen and (max-width: 500px) {
    .slider{
      width: 0px;
      height: 0px;

    }
  }


</style>
  <div id="carousel" data-ride="carousel" class="carousel slide" data-interval="5000"
       data-wrap="true" data-pause="hover">
    <ul class="carousel-inner" role="listbox">
              <li class="carousel-item active" role="option"
            aria-hidden="false">
          <a href="https://www.sicar.mx">
            <figure>
              <img src="http://finaltest2.com/modules/ps_imageslider/images/sample-1.jpg" alt="sample-1">
                          </figure>
          </a>
        </li>
              <li class="carousel-item " role="option"
            aria-hidden="true">
          <a href="https://www.sicar.mx">
            <figure>
              <img src="http://finaltest2.com/modules/ps_imageslider/images/sample-2.jpg" alt="sample-2">
                          </figure>
          </a>
        </li>
              <li class="carousel-item " role="option"
            aria-hidden="true">
          <a href="https://www.sicar.mx">
            <figure>
              <img src="http://finaltest2.com/modules/ps_imageslider/images/sample-3.jpg" alt="sample-3">
                          </figure>
          </a>
        </li>
          </ul>
    <div class="direction" aria-label="Botones del carrusel">
      <a class="left carousel-control" href="#carousel" role="button" data-slide="prev">
        <span class="icon-prev hidden-xs" aria-hidden="true">
          <div class="slider">
          <i class="material-icons">&#xE5CB;</i>
           </div>
        </span>
        <span class="sr-only">Anterior</span>
      </a>
      <a class="right carousel-control" href="#carousel" role="button" data-slide="next">
        <span class="icon-next" aria-hidden="true">
            <div class="slider">
          <i class="material-icons">&#xE5CC;</i>
           </div>
        </span>
        <span class="sr-only">Siguiente</span>
      </a>
    </div>
  </div>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
    .MultiCarousel { float: left; overflow: hidden; padding: 15px; width: 100%; height: 100%; position:relative; }
    .MultiCarousel .MultiCarousel-inner { transition: 1s ease all; float: left; }
    .MultiCarousel .MultiCarousel-inner .item { float: left;}
    .MultiCarousel .MultiCarousel-inner .item > div { text-align: center; padding:10px; margin:10px; background:#f1f1f1; color:#666;}
    .MultiCarousel .leftLst, .MultiCarousel .rightLst { position:absolute; border-radius:50%;top:calc(50% - 20px); }
    .MultiCarousel .leftLst { left:0; }
    .MultiCarousel .rightLst { right:0; }
    .MultiCarousel .leftLst.over, .MultiCarousel .rightLst.over { pointer-events: none; background:#ccc; }
    .menuLe{
      /*  padding-right: 80%;
        margin-right: 80%;*/
    }
    .menuLe{

    }

</style>

<script>
    $(document).ready(function () {
        var itemsMainDiv = ('.MultiCarousel');
        var itemsDiv = ('.MultiCarousel-inner');
        var itemWidth = "";

        $('.leftLst, .rightLst').click(function () {
            var condition = $(this).hasClass("leftLst");
            if (condition)
                click(0, this);
            else
                click(1, this)
        });
        ResCarouselSize();
        $(window).resize(function () {
            ResCarouselSize();
        });
        function ResCarouselSize() {
            var incno = 0;
            var dataItems = ("data-items");
            var itemClass = ('.item');
            var id = 0;
            var btnParentSb = '';
            var itemsSplit = '';
            var sampwidth = $(itemsMainDiv).width();
            var bodyWidth = $('body').width();
            $(itemsDiv).each(function () {
                id = id + 1;
                var itemNumbers = $(this).find(itemClass).length;
                btnParentSb = $(this).parent().attr(dataItems);
                itemsSplit = btnParentSb.split(',');
                $(this).parent().attr("id", "MultiCarousel" + id);


                if (bodyWidth >= 1200) {
                    incno = itemsSplit[3];
                    itemWidth = sampwidth / incno;
                }
                else if (bodyWidth >= 992) {
                    incno = itemsSplit[2];
                    itemWidth = sampwidth / incno;
                }
                else if (bodyWidth >= 768) {
                    incno = itemsSplit[1];
                    itemWidth = sampwidth / incno;
                }
                else {
                    incno = itemsSplit[0];
                    itemWidth = sampwidth / incno;
                }
                $(this).css({ 'transform': 'translateX(0px)', 'width': itemWidth * itemNumbers });
                $(this).find(itemClass).each(function () {
                    $(this).outerWidth(itemWidth);
                });

                $(".leftLst").addClass("over");
                $(".rightLst").removeClass("over");

            });
        }
        function ResCarousel(e, el, s) {
            var leftBtn = ('.leftLst');
            var rightBtn = ('.rightLst');
            var translateXval = '';
            var divStyle = $(el + ' ' + itemsDiv).css('transform');
            var values = divStyle.match(/-?[\d\.]+/g);
            var xds = Math.abs(values[4]);
            if (e == 0) {
                translateXval = parseInt(xds) - parseInt(itemWidth * s);
                $(el + ' ' + rightBtn).removeClass("over");

                if (translateXval <= itemWidth / 2) {
                    translateXval = 0;
                    $(el + ' ' + leftBtn).addClass("over");
                }
            }
            else if (e == 1) {
                var itemsCondition = $(el).find(itemsDiv).width() - $(el).width();
                translateXval = parseInt(xds) + parseInt(itemWidth * s);
                $(el + ' ' + leftBtn).removeClass("over");

                if (translateXval >= itemsCondition - itemWidth / 2) {
                    translateXval = itemsCondition;
                    $(el + ' ' + rightBtn).addClass("over");
                }
            }
            $(el + ' ' + itemsDiv).css('transform', 'translateX(' + -translateXval + 'px)');
        }
        function click(ell, ee) {
            var Parent = "#" + $(ee).parent().attr("id");
            var slide = $(Parent).attr("data-slide");
            ResCarousel(ell, Parent, slide);
        }
    });
</script>

<section class="featured-products clearfix">
    <h2 class="h2 products-section-title text-uppercase">
        Productos Destacados
    </h2>
</section>


<!------ Include the above in your HEAD tag ---------->
<div class="container">
    <div class="row">
        <div class="MultiCarousel" data-items="1,3,3,4" data-slide="1" id="MultiCarousel"  data-interval="1000">
            <div class="MultiCarousel-inner">
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="1"
             data-id-product-attribute="1" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=1&amp;id_product_attribute=1&amp;rewrite=hummingbird-printed-t-shirt&amp;controller=product#/1-tamano-s/8-color-blanco" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/2/2-home_default.jpg"
                                alt="Hummingbird printed t-shirt"
                                data-full-size-image-url="http://finaltest2.com/img/p/2/2-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=1&amp;id_product_attribute=1&amp;rewrite=hummingbird-printed-t-shirt&amp;controller=product#/1-tamano-s/8-color-blanco">Hummingbird printed t-shirt</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                            
                                <span class="sr-only">Precio base</span>
                                <span class="regular-price">23,90 $</span>
                                                                    <span class="discount-percentage discount-product">-20%</span>
                                                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">19,12 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <div class="pasrp">
                                <li id="pasrp" class="product-flag discount" style="background: " >-20%</li>
                            </div>
                                                                                                                        <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                            <div class="variant-links">
      <a href="http://finaltest2.com/index.php?id_product=1&amp;id_product_attribute=3&amp;rewrite=hummingbird-printed-t-shirt&amp;controller=product#/2-tamano-m/8-color-blanco"
       class="color"
       title="Blanco"
              style="background-color: #ffffff"           ><span class="sr-only">Blanco</span></a>
      <a href="http://finaltest2.com/index.php?id_product=1&amp;id_product_attribute=2&amp;rewrite=hummingbird-printed-t-shirt&amp;controller=product#/1-tamano-s/11-color-negro"
       class="color"
       title="Negro"
              style="background-color: #434A54"           ><span class="sr-only">Negro</span></a>
    <span class="js-count count"></span>
</div>
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="2"
             data-id-product-attribute="9" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=2&amp;id_product_attribute=9&amp;rewrite=brown-bear-printed-sweater&amp;controller=product#/1-tamano-s" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/2/1/21-home_default.jpg"
                                alt="Brown bear printed sweater"
                                data-full-size-image-url="http://finaltest2.com/img/p/2/1/21-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=2&amp;id_product_attribute=9&amp;rewrite=brown-bear-printed-sweater&amp;controller=product#/1-tamano-s">Hummingbird printed sweater</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                            
                                <span class="sr-only">Precio base</span>
                                <span class="regular-price">35,90 $</span>
                                                                    <span class="discount-percentage discount-product">-20%</span>
                                                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">28,72 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <div class="pasrp">
                                <li id="pasrp" class="product-flag discount" style="background: " >-20%</li>
                            </div>
                                                                                                                        <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="3"
             data-id-product-attribute="13" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=3&amp;id_product_attribute=13&amp;rewrite=the-best-is-yet-to-come-framed-poster&amp;controller=product#/19-dimension-40x60cm" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/3/3-home_default.jpg"
                                alt="The best is yet to come&#039; Framed poster"
                                data-full-size-image-url="http://finaltest2.com/img/p/3/3-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=3&amp;id_product_attribute=13&amp;rewrite=the-best-is-yet-to-come-framed-poster&amp;controller=product#/19-dimension-40x60cm">The best is yet to come&#039;...</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">29,00 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="4"
             data-id-product-attribute="16" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=4&amp;id_product_attribute=16&amp;rewrite=the-adventure-begins-framed-poster&amp;controller=product#/19-dimension-40x60cm" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/4/4-home_default.jpg"
                                alt="The adventure begins Framed poster"
                                data-full-size-image-url="http://finaltest2.com/img/p/4/4-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=4&amp;id_product_attribute=16&amp;rewrite=the-adventure-begins-framed-poster&amp;controller=product#/19-dimension-40x60cm">The adventure begins Framed...</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">29,00 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="5"
             data-id-product-attribute="19" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=5&amp;id_product_attribute=19&amp;rewrite=today-is-a-good-day-framed-poster&amp;controller=product#/19-dimension-40x60cm" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/5/5-home_default.jpg"
                                alt="Today is a good day Framed poster"
                                data-full-size-image-url="http://finaltest2.com/img/p/5/5-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=5&amp;id_product_attribute=19&amp;rewrite=today-is-a-good-day-framed-poster&amp;controller=product#/19-dimension-40x60cm">Today is a good day Framed...</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">29,00 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="6"
             data-id-product-attribute="0" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=6&amp;rewrite=mug-the-best-is-yet-to-come&amp;controller=product" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/6/6-home_default.jpg"
                                alt="Mug The best is yet to come"
                                data-full-size-image-url="http://finaltest2.com/img/p/6/6-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=6&amp;rewrite=mug-the-best-is-yet-to-come&amp;controller=product">Mug The best is yet to come</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">11,90 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="7"
             data-id-product-attribute="0" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=7&amp;rewrite=mug-the-adventure-begins&amp;controller=product" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/7/7-home_default.jpg"
                                alt="Mug The adventure begins"
                                data-full-size-image-url="http://finaltest2.com/img/p/7/7-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=7&amp;rewrite=mug-the-adventure-begins&amp;controller=product">Mug The adventure begins</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">11,90 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                  <div class="item">
                    <div class="pad15">
                    <style>
    #fla {
        background: #FEC34F;
        height: 60px;
        width: 60px;
        background-repeat: no-repeat;
        /*   background-position: 50%;*/
        border-radius: 50%;
        /*    background-size: 100% auto;*/
        padding-top: 8.5%;
        margin-top: 70%;
        margin-left: 75%;
        color: white;
        font-size: 12px;
    }
    .ccc {
        padding-left: 20%;
        padding-right: 20%;
        padding-top: 25%;
    }

    .mar {
        margin-left: 0px;
        padding-left: 0px;
        margin: 0px;
        padding: 0px;
    }

    #pasrp {
        width: 30px;
        height: 30px;
        background: red;
        margin: -0.5px;
        padding-top: 8px;
    }
</style>


    <article class="product-miniature js-product-miniature " data-id-product="8"
             data-id-product-attribute="0" itemscope itemtype="http://schema.org/Product">
        <div class="thumbnail-container">
            
                                    <a href="http://finaltest2.com/index.php?id_product=8&amp;rewrite=mug-today-is-a-good-day&amp;controller=product" class="thumbnail product-thumbnail">
                        <img
                                src="http://finaltest2.com/img/p/8/8-home_default.jpg"
                                alt="Mug Today is a good day"
                                data-full-size-image-url="http://finaltest2.com/img/p/8/8-large_default.jpg"
                        >
                    </a>
                            

            <div class="product-description">
                
                                            <h3 class="h3 product-title" itemprop="name"><a
                                    href="http://finaltest2.com/index.php?id_product=8&amp;rewrite=mug-today-is-a-good-day&amp;controller=product">Mug Today is a good day</a></h3>
                                    

                
                                            <div class="product-price-and-shipping">
                                                        
                            <span class="sr-only">Precio</span>
                            <span itemprop="price" class="price">11,90 $</span>
                            
                            
                        </div>
                                    
                
                    
                
            </div>

            
                <ul class="product-flags">
                                                                                                <li id="fla" class="product-flag new" style="background: ;">Nuevo</li>
                                                            </ul>
            
            <div class="highlighted-informations no-variants hidden-sm-down">
                
                    <a class="quick-view" href="#" data-link-action="quickview">
                        <i class="material-icons search">&#xE8B6;</i> Vista rápida
                    </a>
                
                
                                    
            </div>
        </div>
    </article>









            




   </div>
                </div>
                            </div>
            <button class="btn btn-primary leftLst"><</button>
            <button class="btn btn-primary rightLst">></button>
        </div>
    </div>
    <section class="featured-products clearfix">
        <a class="all-product-link float-xs-left float-md-right h4" href="http://finaltest2.com/index.php?id_category=2&amp;controller=category">
            Todos los productos<i class="material-icons">&#xE315;</i>
        </a>
    </section>
</div>
<a class="banner" href="http://finaltest2.com/index.php" title="">
      <img src="http://finaltest2.com/modules/ps_banner/img/sale70.png" alt="" title="" class="img-fluid">
  </a>
<div id="custom-text">
  <h2>Custom Text Block</h2>
<p><strong class="dark">Lorem ipsum dolor sit amet conse ctetu</strong></p>
<p>Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.</p>
</div>


            
        
    </section>


    
      <footer class="page-footer">
        
          <!-- Footer content -->
        
      </footer>
    

  </section>


    
  </div>


          
        </div>
        
      </section>

      <footer id="footer">
        
          
<div class="container">
    <div class="footersucribe">
        <div class="row">
            
                <div class="block_newsletter col-lg-8 col-md-12 col-sm-12 new_block">
  <div class="row">
    <p id="block-newsletter-label" class="col-md-5 col-xs-12 bannerleter">Infórmese de nuestras últimas noticias y ofertas especiales</p>
    <div class="col-md-7 col-xs-12">
      <form action="http://finaltest2.com/index.php#footer" method="post">
        <div class="row">
          <div class="col-xs-12 suscr">
            <input
              class="btn btn-primary float-xs-right hidden-xs-down"
              name="submitNewsletter"
              id="submitNewsletter"
              type="submit"
              value="Suscribirse"
            >
            <input
              class="btn btn-primary float-xs-right hidden-sm-up"
              name="submitNewsletter"
              type="submit"
              value="OK"
            >
            <div class="input-wrapper">
              <input
                name="email"
                type="email"
                value=""
                placeholder="Su dirección de correo electrónico"
                aria-labelledby="block-newsletter-label"
              >
            </div>
            <input type="hidden" name="action" value="0">
            <div class="clearfix"></div>
          </div>
          <div class="col-xs-12">
                              <p class="bannerleter">Puede darse de baja en cualquier momento. Para ello, consulte nuestra información de contacto en el aviso legal.</p>
                                                          
                        </div>
        </div>
      </form>
    </div>
  </div>
</div>
<style>

</style>    <div class="block-social col-lg-2 col-md-12 col-sm-12" xmlns="http://www.w3.org/1999/html">
        <ul>
                    </ul>
    </div>


            
        </div>
    </div>
</div>
<div class="footer-container contenn">
    <div class="container cojdsd">
        <div class="row">
            
                <style>
  .bsd {
    list-style-type: square;
  }
</style>


<style>

  .ir-arriba {
    display:block;
    padding:15px;
    background:#81c9eb;
    font-size:20px;
    color:#fff;
    cursor:pointer;
    position: fixed;
    bottom:20px;
    right:20px;

  }


</style>
<img  class="ir-arriba" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAQAAABKfvVzAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAHdElNRQfjAwsWLA4Kh6c2AAAAU0lEQVQ4y+XLMRLAIAwDQc7//zNpYAaMYqUOLq291i481LP3MfIpmFwnVFwl1PxMcDwneL4naA7qswR6VF/euV6ouEqo+ZmE4/kbjuclPPfr7+8BAp0gHFO6lkYAAAAASUVORK5CYII=" alt="">
<div class="col-md-4 links">
  <div class="row">
      <div class="col-md-6 wrapper">
    <p class="h3 hidden-sm-down">
      Products</p>
            <div class="title clearfix hidden-md-up" data-target="#footer_sub_menu_23503" data-toggle="collapse">
        <span class="h3">Products</span>
        <span class="float-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="material-icons add">&#xE313;</i>
            <i class="material-icons remove">&#xE316;</i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_23503" class="collapse bsd">
                  <li>
            <a
                id="link-product-page-prices-drop-1"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=prices-drop"
                title="Our special products"
                            >
              Ofertas
            </a>
          </li>
                  <li>
            <a
                id="link-product-page-new-products-1"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=new-products"
                title="Novedades"
                            >
              Novedades
            </a>
          </li>
                  <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=best-sales"
                title="Los más vendidos"
                            >
              Los más vendidos
            </a>
          </li>
              </ul>
    </div>
      <div class="col-md-6 wrapper">
    <p class="h3 hidden-sm-down">
      Our company</p>
            <div class="title clearfix hidden-md-up" data-target="#footer_sub_menu_75211" data-toggle="collapse">
        <span class="h3">Our company</span>
        <span class="float-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="material-icons add">&#xE313;</i>
            <i class="material-icons remove">&#xE316;</i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_75211" class="collapse bsd">
                  <li>
            <a
                id="link-cms-page-1-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?id_cms=1&amp;controller=cms"
                title="Nuestros términos y condiciones de envío"
                            >
              Envío
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-2-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?id_cms=2&amp;controller=cms"
                title="Aviso legal"
                            >
              Aviso legal
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-3-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?id_cms=3&amp;controller=cms"
                title="Nuestros términos y condiciones"
                            >
              Términos y condiciones
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-4-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?id_cms=4&amp;controller=cms"
                title="Averigüe más sobre nosotros"
                            >
              Sobre nosotros
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-5-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?id_cms=5&amp;controller=cms"
                title="Nuestra forma de pago segura"
                            >
              Pago seguro
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-contact-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=contact"
                title="Contáctenos"
                            >
              Contacte con nosotros
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-sitemap-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=sitemap"
                title="¿Perdido? Encuentre lo que está buscando"
                            >
              Mapa del sitio
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-stores-2"
                class="cms-page-link"
                href="http://finaltest2.com/index.php?controller=stores"
                title=""
                            >
              Tiendas
            </a>
          </li>
              </ul>
    </div>
    </div>
</div>
<style>
  .bsd {
    list-style-type: square;
    font-weight: bold;
    font-size: 8px;
  }
</style>
<div id="block_myaccount_infos" class="col-md-2 links wrapper">
  <p class="h3 myaccount-title hidden-sm-down">
    <a class="text-uppercase" href="http://finaltest2.com/index.php?controller=my-account" rel="nofollow">
      Su cuenta
    </a>
  </p>
  <div class="title clearfix hidden-md-up" data-target="#footer_account_list" data-toggle="collapse">
    <span class="h3">Su cuenta</span>
    <span class="float-xs-right">
      <span class="navbar-toggler collapse-icons">
        <i class="material-icons add">&#xE313;</i>
        <i class="material-icons remove">&#xE316;</i>
      </span>
    </span>
  </div>
  <ul class="account-list collapse bsd" id="footer_account_list">
            <li>
          <a href="http://finaltest2.com/index.php?controller=identity" title="Información personal" rel="nofollow">
            Información personal
          </a>
        </li>
            <li>
          <a href="http://finaltest2.com/index.php?controller=history" title="Pedidos" rel="nofollow">
            Pedidos
          </a>
        </li>
            <li>
          <a href="http://finaltest2.com/index.php?controller=order-slip" title="Facturas por abono" rel="nofollow">
            Facturas por abono
          </a>
        </li>
            <li>
          <a href="http://finaltest2.com/index.php?controller=addresses" title="Direcciones" rel="nofollow">
            Direcciones
          </a>
        </li>
        
	</ul>
</div>
<div class="block-contact col-md-4 links wrapper">
  <div class="hidden-sm-down">
    <p class="h4 text-uppercase block-contact-title">Información de la tienda</p>
      ecommerce sicar<br />Mexico
                          <br>
                Envíenos un correo electrónico: <a href="mailto:pub@prestashop.com" class="dropdown">pub@prestashop.com</a>
        </div>
  <div class="hidden-md-up">
    <div class="title">
      <a class="h3" href="http://finaltest2.com/index.php?controller=stores">Información de la tienda</a>
    </div>
  </div>
</div>

            
        </div>
        <div class="row">
            
                
            
        </div>

    </div>
    <div class="klksd">
    <p class="text-sm-center">
        
            <a href="https://www.sicar.mx" style="color:#a2c1e0;" class="_blank" target="_blank">Copyright © SICAR SOLUTIONS SA DE
                CV</a>
        
    </p>
    </div>
</div>
        
      </footer>

    </main>

    
        <script type="text/javascript" src="http://finaltest2.com/themes/core.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/themes/classic/assets/js/theme.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/js/jquery/ui/jquery-ui.min.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/modules/ps_imageslider/js/responsiveslides.min.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/modules/ps_imageslider/js/homeslider.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/modules/ps_searchbar/ps_searchbar.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/modules/ps_shoppingcart/ps_shoppingcart.js" ></script>
  <script type="text/javascript" src="http://finaltest2.com/themes/classic/assets/js/custom.js" ></script>


    

    
      
    
  </body>

</html>